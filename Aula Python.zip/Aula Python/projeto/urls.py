
from django.contrib import admin
from django.urls import path, include
from django.http import HttpResponse
from blog import views as blog_views

def view(request):
    return HttpResponse('pagina inicial')

urlpatterns = [
    # path('admin/', admin.sites.urls),
    path('', blog_views.blog)
]